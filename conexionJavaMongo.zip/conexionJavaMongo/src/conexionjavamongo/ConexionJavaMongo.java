/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexionjavamongo;

/**
 *
 * @author yair1
 */
public class ConexionJavaMongo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Conexion conec = new Conexion();
        //conec.insertar("Nadar");
        //conec.Mostrar();
        //conec.Actualizar("correr", "brincar");
        conec.Mostrar();
        conec.Eliminar("Nadar");
        conec.Mostrar();
    }
    
}
